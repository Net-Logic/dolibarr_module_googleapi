
## Unreleased (2025-09-22)

#### :memo: Documentation
* [#22](https://github.com/Net-Logic/dolibarr_module_googleapi/pull/22) translations ([@frederic34](https://github.com/frederic34))
* [#9](https://github.com/Net-Logic/dolibarr_module_googleapi/pull/9) translations ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))


## v1.0.0 (2022-02-20)

#### :rocket: Enhancement
* [#1](https://github.com/Net-Logic/dolibarr_module_googleapi/pull/1) add work on extrafields ([@frederic34](https://github.com/frederic34))

#### :bug: Bug Fix
* [#3](https://github.com/Net-Logic/dolibarr_module_googleapi/pull/3) fix tz ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
