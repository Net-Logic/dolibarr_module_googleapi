-- actioncomm code 12 chars MAX
INSERT INTO llx_c_actioncomm (id, code, type, libelle, module, active, todo, color, picto, position)
VALUES (135290, 'AC_GAPI_CAL', 'module', 'Evènement Calendrier externe', 'googleapi@googleapi', 1, NULL, NULL, 'object_googleapi@googleapi', 135290);
