<?php
/*
 * Copyright (C) 2019-2025  Frédéric France         <frederic.france@netlogic.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * \file    htdocs/googleapi/class/actions_googleapi.class.php
 * \ingroup googleapi
 * \brief   Example hook overload.
 *
 * Put detailed description here.
 */

dol_include_once('/prune/lib/prune.lib.php');
dol_include_once('/prune/vendor/autoload.php');
dol_include_once('/googleapi/lib/googleapi.lib.php');


/**
 * Class ActionsGoogleApi
 */
class ActionsGoogleApi
{
	/**
	 * @var DoliDB Database handler.
	 */
	public $db;

	/**
	 * @var string Error code (or message)
	 */
	public $error = '';

	/**
	 *  @var array Errors
	 */
	public $errors = [];

	/**
	 *  @var array Warnings
	 */
	public $warnings = [];

	/**
	 *  @var array Hook results. Propagated to $hookmanager->resArray for later reuse
	 */
	public $results = [];

	/**
	 *  @var string String displayed by executeHook() immediately after return
	 */
	public $resprints;

	/**
	 *  Constructor
	 *
	 *  @param  DoliDB  $db      Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * Overloading the moveUploadedFile function.
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function moveUploadedFile($parameters, &$object, &$action, $hookmanager)
	{
		global $conf, $user, $langs;
		// hook fileslib
		// add or rename ==> moveUploadedFile
		// delete ==> deleteFile
		if (!empty($conf->global->GOOGLEAPI_ENABLE_DEVELOPPER_MODE)) {
			setEventMessage('hook fichier googleapi déplacé dans ' . $object->element);
		}

		return 0;
	}

	/**
	 * Overloading the deleteFile function.
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function deleteFile($parameters, $object, &$action, $hookmanager)
	{
		global $conf, $user, $langs;
		//setEventMessage('hook fichier googleapi effacé depuis ' . $object->element);

		return 0;
	}

	/**
	 * Execute action doActions
	 *
	 * @param   array           $parameters     Array of parameters
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         'add', 'update', 'view'
	 * @param   Hookmanager     $hookmanager    hookmanager
	 * @return  int                             <0 if KO,
	 *                                          =0 if OK but we want to process standard actions too,
	 *                                          >0 if OK and we want to replace standard actions.
	 */
	public function doActions(&$parameters, $object, &$action, $hookmanager)
	{
		global $langs;

		$contexts = explode(':', $parameters['context']);
		if (array_intersect(['actioncard', 'fullcalendardao'], $contexts) && isset($parameters['TRemindTypes'])) {
			$langs->load('googleapi@googleapi');
			$parameters['TRemindTypes'] = array_merge(
				$parameters['TRemindTypes'],
				[
					'googleapiremindemail' => [
						'label' => $langs->trans('GoogleApiRemindByEmail'),
						'disabled' => 0,
						'mode' => 'email',
						'data-html' => img_picto('', 'googleapi@googleapi', 'class="pictofixedwidth"') . $langs->trans('GoogleApiRemindByEmail'),
					],
					'googleapiremindnotif' => [
						'label' => $langs->trans('GoogleApiRemindByNotification'),
						'disabled' => 0,
						'mode' => 'browser',
						'data-html' => img_picto('', 'googleapi@googleapi', 'class="pictofixedwidth"') . $langs->trans('GoogleApiRemindByNotification'),
					]
				]
			);
			$parameters['enablereminders'] = true;
		}

		return 0;
	}

	/**
	 * Execute action updateSession
	 *
	 * @param   array           $parameters     Array of parameters
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         'add', 'update', 'view'
	 * @param   Hookmanager     $hookmanager    hookmanager
	 * @return  int                             <0 if KO,
	 *                                          =0 if OK but we want to process standard actions too,
	 *                                          >0 if OK and we want to replace standard actions.
	 */
	public function updateSession(&$parameters, $object, &$action, $hookmanager)
	{
		// Redirecting some core pages
		if (((int) DOL_VERSION <= 23) && strpos($_SERVER['PHP_SELF'], 'comm/action/card.php') !== false) {
			$redirUrl = dol_buildpath('/googleapi/tabs/action/card.php', 1);

			if ($redirUrl !== $_SERVER["PHP_SELF"]) {
				header("Location: {$redirUrl}?" . (!empty($_GET) ? http_build_query($_GET) : ''));
				exit;
			}
		}

		return 0;
	}

	/**
	 * Execute action completeTabsHead
	 *
	 * @param   array           $parameters     Array of parameters
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         'add', 'update', 'view'
	 * @param   Hookmanager     $hookmanager    hookmanager
	 * @return  int                             <0 if KO,
	 *                                          =0 if OK but we want to process standard actions too,
	 *                                          >0 if OK and we want to replace standard actions.
	 */
	public function completeTabsHead(&$parameters, $object, &$action, $hookmanager)
	{
		global $langs, $conf, $user;

		if (!isset($parameters['object']->element)) {
			return 0;
		}
		if ($parameters['mode'] == 'remove') {
			// utilisé si on veut faire disparaitre des onglets.
			return 0;
		} elseif ($parameters['mode'] == 'add') {
			if (isset($parameters['filterorigmodule']) && $parameters['filterorigmodule'] == 'core') {
				// avoid to have two tabs when filter is active
				return 0;
			}
			$langs->load('googleapi@googleapi');
			// utilisé si on veut ajouter des onglets.
			$counter = count($parameters['head']);
			$element = $parameters['object']->element;
			$id = $parameters['object']->id;
			// verifier le type d'onglet comme member_stats où ça ne doit pas apparaitre
			if (in_array($element, ['societe', 'member', 'contrat', 'fichinter', 'project', 'propal', 'commande', 'facture', 'order_supplier', 'invoice_supplier'])) {
				require_once DOL_DOCUMENT_ROOT . '/core/lib/memory.lib.php';
				$emailcount = 0;
				$cachekey = 'count_gapiemails_' . $element . '_' . $id;
				$dataretrieved = dol_getcache($cachekey);
				if (!is_null($dataretrieved)) {
					$emailcount = $dataretrieved;
				} else {
					$sql = 'SELECT count(rowid) as nb FROM ' . MAIN_DB_PREFIX . 'googleapi_emails_sent';
					$sql .= ' WHERE userid=' . (int) $user->id . ' AND module="' . $element . '"';
					$sql .= ' AND fk_object=' . (int) $id;
					$resql = $this->db->query($sql);
					if ($resql && $obj = $this->db->fetch_object($resql)) {
						$emailcount = (int) $obj->nb;
					}
					// If setting cache fails, this is not a problem, so we do not test result.
					dol_setcache($cachekey, $emailcount, 120);
				}
				$parameters['head'][$counter][0] = dol_buildpath('/googleapi/tabs/googleapi_emails.php', 1) . '?id=' . $id . '&amp;module=' . $element;
				$parameters['head'][$counter][1] = img_picto($langs->trans('GoogleApiMailsTab'), 'object_googleapi@googleapi'); //.$langs->trans('GoogleApiMailsTab');
				if ($emailcount > 0) {
					$parameters['head'][$counter][1] .= '<span class="badge marginleftonlyshort">' . $emailcount . '</span>';
				}
				$parameters['head'][$counter][2] = 'googleapiemails';
				$counter++;
			}
			if (in_array($element, ['user'])) {
				require_once DOL_DOCUMENT_ROOT . '/core/lib/memory.lib.php';
				$parameters['head'][$counter][0] = dol_buildpath('/googleapi/tabs/usertoken.php', 1) . '?id=' . $id;
				$parameters['head'][$counter][1] = img_picto($langs->trans('GoogleApiTokenTab'), 'object_googleapi@googleapi');
				$parameters['head'][$counter][2] = 'googleapitoken';
				$counter++;
			}
			if (((int) DOL_VERSION <= 23) && in_array($element, ['action'])) {
				foreach ($parameters['head'] as $key => $value) {
					if (strpos($parameters['head'][$key][0], 'comm/action/card.php?id') !== false) {
						$parameters['head'][$key][0] = dol_buildpath('/googleapi/tabs/action/card.php', 1) . '?id=' . $id;
					}
				}
			}
			if ($counter > 0 && (int) DOL_VERSION < 14) {
				$this->results = $parameters['head'];
				// return 1 to replace standard code
				return 1;
			} else {
				// en V14 et + $parameters['head'] est modifiable par référence
				return 0;
			}
		}

		return 0;
	}

	/**
	 * Overloading the sendMail function : replacing the parent's function with the one below
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CmailFile    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function sendMail($parameters, $object, &$action, $hookmanager)
	{
		global $conf, $user, $langs, $googleapiMessageId;

		$error = 0; // Error counter
		$contexts = explode(':', $parameters['context']);

		$context = $object->sendcontext ?? 'standard';
		$googleapicontexts = json_decode(getDolGlobalString('GOOGLEAPI_CONTEXTS_TO_SEND', '{}'), true);
		if (empty($googleapicontexts)) {
			// set default
			dolibarr_set_const($this->db, 'GOOGLEAPI_CONTEXTS_TO_SEND', json_encode(['standard' => true]), 'chaine', 0, '', $conf->entity);
			$googleapicontexts = json_decode(getDolGlobalString('GOOGLEAPI_CONTEXTS_TO_SEND', '{}'), true);
		}
		if (!array_key_exists($context, $googleapicontexts)) {
			// we found a new context
			$googleapicontexts = array_merge($googleapicontexts, [$context => false]);
			dolibarr_set_const($this->db, 'GOOGLEAPI_CONTEXTS_TO_SEND', json_encode($googleapicontexts), 'chaine', 0, '', $conf->entity);
		}
		$googleapicontextsok = [];
		foreach ($googleapicontexts as $key => $item) {
			if ($item) {
				$googleapicontextsok[] = $key;
			}
		}
		// what TODO with context 'emailing'
		// context notification?
		// https://developers.google.com/resources/api-libraries/documentation/gmail/v1/php/latest/class-Google_Service_Gmail_Message.html
		if (in_array($context, $googleapicontextsok)) {
			dol_include_once('/googleapi/lib/googleapi.lib.php');
			$fromsender = $this->getArrayAddress($object->addr_from);
			if (!empty($user->array_options['options_googleapi_email']) && $fromsender[0]['address'] == $user->array_options['options_googleapi_email']) {
				$client = getGoogleApiClient($user);
				$service = new Google\Service\Gmail($client);

				$message = new Google\Service\Gmail\Message();
				$mime = rtrim(strtr(base64_encode($this->buildRawMessage($object)), '+/', '-_'), '=');
				$message->setRaw($mime);

				$mailsent = false;
				$response = null;
				try {
					$response = $service->users_messages->send('me', $message);
					$mailsent = true;
				} catch (Exception $e) {
					$this->errors[] = $e->getMessage();
					setEventMessage($e->getMessage(), 'errors');
					$error++;
				}
				if ($mailsent) {
					$googleapiMessageId = $response->getId();
				}
			} else {
				// nothing done
				return 0;
			}
		}

		if (!$error) {
			// 1 si on a envoyé avec googleapi sinon 0
			return 1; // or return 1 to replace standard code
		} else {
			$this->errors[] = 'Error in googleapi module';
			return -1;
		}
	}

	/**
	 * Build a full RFC 822 raw message (headers + body + attachments) from a CMailFile object,
	 * suitable for the Gmail API 'raw' field.
	 *
	 * CMailFile only populates $object->headers/$object->message (the MIME parts used here) when
	 * $object->sendmode == 'mail'. On this instance MAIN_MAIL_SENDMODE is 'smtps', so those
	 * properties are never filled and used to be encoded empty, silently breaking every mail sent
	 * through this hook. Rebuilding the message here from data that CMailFile always populates
	 * (subject, addr_to/cc/bcc, html/msg, attachments, ...) makes this independent of sendmode.
	 *
	 * @param   CMailFile   $object     The mail object to process
	 * @return  string                  Full raw RFC 822 message
	 */
	private function buildRawMessage($object)
	{
		$subjecttouse = $object->subject;
		if (!ascii_check($subjecttouse)) {
			$subjecttouse = CMailFile::encodetorfc2822($subjecttouse);
		}

		$headers = "To: " . CMailFile::getValidAddress($object->addr_to, 0, 1) . $object->eol2;
		$headers .= "Subject: " . $subjecttouse . $object->eol2;
		$headers .= $object->write_smtpheaders();
		$headers .= $object->write_mimeheaders($object->filename_list, $object->mimefilename_list);
		$headers = preg_replace("/([\r\n]+)$/i", "", $headers);

		$msgforbody = $object->msgishtml ? $object->html : $object->msg;
		$body = $object->write_body($msgforbody);

		$filesencoded = '';
		if (!empty($object->atleastonefile) && is_array($object->filename_list)) {
			$refmethod = new ReflectionMethod($object, 'write_files');
			$refmethod->setAccessible(true);
			$result = $refmethod->invoke($object, $object->filename_list, $object->mimetype_list, $object->mimefilename_list, $object->cid_list);
			if (is_string($result)) {
				$filesencoded = $result;
			}
		}

		$rawmessage = $headers . $object->eol . $object->eol; // Blank line to separate headers from body
		$rawmessage .= $body . $filesencoded;
		$rawmessage .= "--" . $object->mixed_boundary . "--" . $object->eol;

		return $rawmessage;
	}

	/**
	 * Execute printFieldListOption
	 *
	 * @param   array           $parameters     Array of parameters
	 * @param   CommonObject    $object         Object
	 * @param   string          $action         'add', 'update', 'view'
	 * @return  int                             <0 if KO,
	 *                                          =0 if OK but we want to process standard actions too,
	 *                                          >0 if OK and we want to replace standard actions.
	 */
	public function printFieldListOption($parameters, $object, &$action)
	{
		global $conf, $langs;

		$ret = 0;

		dol_syslog(get_class($this) . '::executeHooks action=' . $action, LOG_DEBUG);

		$contexts = explode(':', $parameters['context']);
		if (in_array('emailsenderprofilelist', $contexts)) {
			$langs->load('googleapi@googleapi');
			$this->resprints = '<td class="center">' . img_picto($langs->trans('GoogleApiSenderProfile'), 'object_googleapi@googleapi') . '</td>';
		}

		return $ret;
	}

	/**
	 * Execute printFieldListTitle
	 *
	 * @param   array   $parameters     Array of parameters
	 * @param   Object  $object         Object
	 * @param   string  $action         'add', 'update', 'view'
	 * @return  int                     <0 if KO,
	 *                                  =0 if OK but we want to process standard actions too,
	 *                                  >0 if OK and we want to replace standard actions.
	 */
	public function printFieldListTitle($parameters, $object, &$action)
	{
		global $conf, $langs;

		$ret = 0;

		dol_syslog(get_class($this) . '::executeHooks action=' . $action, LOG_DEBUG);

		$contexts = explode(':', $parameters['context']);
		if (in_array('emailsenderprofilelist', $contexts)) {
			$this->resprints = '<td class="center">Token ' . img_warning($langs->trans('GoogleApiDisconnectWarning')) . '</td>';
		}

		return $ret;
	}

	/**
	 * Execute printFieldListValue
	 *
	 * @param   array   $parameters     Array of parameters
	 * @param   Object  $object         Object
	 * @param   string  $action         'add', 'update', 'view'
	 * @return  int                     <0 if KO,
	 *                                  =0 if OK but we want to process standard actions too,
	 *                                  >0 if OK and we want to replace standard actions.
	 */
	public function printFieldListValue($parameters, $object, &$action)
	{
		global $langs;

		$ret = 0;

		dol_syslog(get_class($this) . '::executeHooks action=' . $action, LOG_DEBUG);

		$contexts = explode(':', $parameters['context']);
		if (in_array('emailsenderprofilelist', $contexts)) {
			$token = retrieveAccessToken('GoogleApi', 0, $parameters['object']->email);
			$oauthcallbackurl = dol_buildpath('googleapi/core/modules/oauth/googleapi_oauthcallback.php', 1);
			$urltorenew = $oauthcallbackurl . '?mode=emailsenderprofile&emailprofile=' . $parameters['object']->email . '&backtourl=' . rawurlencode(dol_buildpath('/admin/mails_senderprofile_list.php', 1));
			$urltodelete = $oauthcallbackurl . '?action=deletetoken&emailprofile=' . $parameters['object']->email . '&backtourl=' . rawurlencode(dol_buildpath('/admin/mails_senderprofile_list.php', 1));
			if (empty($token)) {
				$this->resprints = '<td class="center nowrap"><a class="button" href="' . $urltorenew . '">' . $langs->trans('GoogleApiRequestAccess') . '</a></td>';
			} else {
				$this->resprints = '<td class="center nowrap"><a class="button butAction butActionDelete" href="' . $urltodelete  . '">' . $langs->trans('GoogleApiDeleteAccess') . '</a></td>';
			}
		}

		return $ret;
	}

	/**
	 * Overloading the sendMailAfter function : replacing the parent's function with the one below
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function sendMailAfter($parameters, $object, &$action, $hookmanager)
	{
		global $conf, $user, $langs;

		$error = 0; // Error counter

		// print '<pre>'.print_r($parameters, true).'</pre>';
		// print '<pre>'.print_r($object, true).'</pre>';
		// print "action: " . $action;exit;
		return 0;
	}

	/**
	 * Edits the login form to allow entering MicosoftGraph Login
	 * @return void
	 */
	public function getLoginPageOptions()
	{
		global $langs, $conf;

		require_once DOL_DOCUMENT_ROOT . '/core/lib/functions2.lib.php';

		$langs->load('googleapi@googleapi');
		$urllogin = 'https://login.google.com/common/oauth2/v2.0/authorize?'; // TODO fix URL
		$urllogin .= 'client_id=' . urlencode(getDolGlobalString('OAUTH_GOOGLEAPI_ID'));
		// id_token sous forme jwt à décoder et valider
		$urllogin .= '&amp;response_type=id_token';
		// TODO check http https
		$urllogin .= '&amp;redirect_uri=' . urlencode(str_replace('http://', 'https://', dol_buildpath('/googleapi/core/modules/oauth/googleapi_oauthcallback.php', 2)));
		$urllogin .= '&amp;response_mode=form_post';
		$urllogin .= '&amp;scope=openid';
		// utiliser state pour dire checklogin
		$urllogin .= '&amp;state=checklogin';
		// générer "nonce" et stocker dans la session pour le vérifier au retour
		$nonce = random_int(100000, 999999);
		$_SESSION['nonce'] = $nonce;
		$urllogin .= '&amp;nonce=' . $nonce;

		$tpl = '<div class="nowrap center valignmiddle">';
		$tpl .= '<a class="butAction" href="' . $urllogin . '">';
		$tpl .= '<img src="' . dol_buildpath('/googleapi/img/google.png', 1) . '" style="width:140px;height:25px;border:0;">';
		$tpl .= '</a>';
		$tpl .= '</div>' . "\n";

		$this->resprints = $tpl;
		return 0;
	}

	/**
	 * Add an icon in the top right menu
	 *
	 * @param   array           $parameters     Hook metadatas (context, etc...)
	 * @param   CommonObject    $object         The object to process (an invoice if you are in invoice module, a propale in propale's module, etc...)
	 * @param   string          $action         Current action (if set). Generally create or edit or null
	 * @param   HookManager     $hookmanager    Hook manager propagated to allow calling another hook
	 * @return  int                             < 0 on error, 0 on success, 1 to replace standard code
	 */
	public function printTopRightMenu($parameters, $object, &$action, $hookmanager)
	{
		global $langs, $conf, $form, $user;

		$langs->load('googleapi@googleapi');
		// require_once DOL_DOCUMENT_ROOT.'/core/lib/functions2.lib.php';
		require_once DOL_DOCUMENT_ROOT . '/core/class/html.form.class.php';
		if (!is_object($form)) {
			$form = new Form($this->db);
		}
		$sql = 'SELECT unread FROM ' . MAIN_DB_PREFIX . 'googleapi_mailboxes WHERE userid=' . (int) $user->id;
		$resql = $this->db->query($sql);
		$unread = 0;
		if ($resql && $obj = $this->db->fetch_object($resql)) {
			$unread = (int) $obj->unread;
		}
		$langs->load('googleapi@googleapi');

		// CSS for Badge Count
		$cssforbadge = '
			<style type="text/css">
				.fa-stack[data-count]:not([data-count="0"]):after{
					position:absolute;
					right:0%;
					top:1%;
					content: attr(data-count);
					font-size:35%;
					padding:.6em;
					border-radius:999px;
					line-height:.75em;
					color: white;
					background:rgba(255,0,0,.85);
					text-align:center;
					min-width:2em;
					font-weight:bold;
				}
			</style>';

		$text = $cssforbadge;
		$text .= '<a href="https://gmail.google.com" target="_blank">';
		//$text.= img_picto(":".$langs->trans("GoogleApiEmailInbox"), 'printer_top.png', 'class="printer"');
		$text .= '<span id="googleapicounter" class="fa-stack fa-1x has-badge atoplogin login_block_elem"' . ($unread > 0 ? ' data-count="' . $unread . '"' : '') . '>';
		$text .= '    <i class="fa fa-envelope fa-stack-1x atoplogin login_block_elem"></i>';
		//$text .= '    <i class="fa fa-bell fa-stack-1x fa-inverse atoplogin login_block_elem"></i>';
		$text .= '</span>';
		$text .= '</a>';
		$info = $langs->trans("GoogleApiUnreadEmailNone");
		if ($unread == 1) {
			$info = $langs->trans("GoogleApiUnreadEmailOne");
		} elseif ($unread > 1) {
			$info = $langs->trans("GoogleApiUnreadEmailMany", $unread);
		}
		$tpl = $form->textwithtooltip('', $info, 2, 1, $text, 'googleapicounterinfo login_block_elem', 2);

		$this->resprints = $tpl;
		return 0;
	}

	/**
	 * Return a formatted array of address string for SMTP protocol
	 *
	 * @param   string  $address    Example: 'John Doe <john@doe.com>, Alan Smith <alan@smith.com>'
	 *                              or 'john@doe.com, alan@smith.com'
	 * @return  array               array of email => name
	 */
	private function getArrayAddress($address)
	{
		global $conf;

		$ret = [];
		if (!empty($address)) {
			$arrayaddress = explode(',', $address);
			// Boucle sur chaque composant de l'adresse
			foreach ($arrayaddress as $val) {
				if (preg_match('/^(.*)<(.*)>$/i', trim($val), $regs)) {
					$name  = trim($regs[1]);
					$email = trim($regs[2]);
				} else {
					$name  = null;
					$email = trim($val);
				}
				$ret[] = [
					'name' => empty($conf->global->MAIN_MAIL_NO_FULL_EMAIL) ? $name : null,
					'address' => $email,
				];
			}
		}

		return $ret;
	}
}
